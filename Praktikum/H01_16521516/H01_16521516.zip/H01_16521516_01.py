# NIM/Nama    : 16521516/Ahmad Nadil
# Tanggal     : 3 Oktober 2021
# Deskripsi   : Program Print Hello, World!

print('Hello, World!') #Memberikan Print/Output berisikan Hello, World!
